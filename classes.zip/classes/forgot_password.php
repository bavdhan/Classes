<!DOCTYPE html>
<head>

</head>
<main class="login-body" data-vide-bg="assets/img/login-bg.mp4">
        <!-- Login Admin -->
        <form class="form-default" action="" method="POST">
            
            <div class="login-form">
                <!-- logo-login -->
                <div class="logo-login">
                    <a href="index.php"><img src="assets/img/logo/loder.png" alt=""></a>
                </div>
                
                <div class="form-input">
                    <label for="name">Email :</label>
                    <input  type="email" name="emailId" placeholder="Email">
                </div>
                <br>
                <br>
                <div class="form-input pt-30">
                    <input type="submit" name="submit" value="send link">
                </div>
                
                <!-- Forget Password -->
                <!-- Forget Password -->
                <br>
                <button><a href="regestration.php" class="registration">Registration</a></button>
            </div>
        </form>
        <!-- /end login form -->
    </main>
    </html>